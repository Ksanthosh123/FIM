﻿Write-Host ""
Write-Host "What would you like to do?"
Write-Host ""
Write-Host "    A) Collect new Baseline?"
Write-Host "    B) Begin monitoring files with saved Baseline?"
Write-Host ""
$response = Read-Host -Prompt "Please enter 'A' or 'B'"
Write-Host ""

Function Calculate-File-Hash($filepath) {
    $filehash = Get-FileHash -Path $filepath -Algorithm SHA512
    return $filehash
}

Function Erase-Baseline-If-Already-Exists() {
    $baselineExists = Test-Path -Path .\baseline.txt
    if ($baselineExists) {
        Remove-Item -Path C:\Users\santh\OneDrive\Desktop\PowerShell-Integrity-FIM-main\PowerShell-Integrity-FIM-main\baseline.txt
    }
}

if ($response.ToUpper() -eq "A") {
    # Delete baseline.txt if it already exists
    Erase-Baseline-If-Already-Exists

    # Calculate Hash from the target files and store in baseline.txt
    # Collect all files in the target folder
    $files = Get-ChildItem C:\Users\santh\OneDrive\Desktop\PowerShell-Integrity-FIM-main\PowerShell-Integrity-FIM-main\Files

    # For each file, calculate the hash, and write to baseline.txt
    foreach ($f in $files) {
        $hash = Calculate-File-Hash $f.FullName
        "$($f.FullName)|$($hash.Hash)" | Out-File -FilePath C:\Users\santh\OneDrive\Desktop\PowerShell-Integrity-FIM-main\PowerShell-Integrity-FIM-main\baseline.txt -Append
    }
} elseif ($response.ToUpper() -eq "B") {
    $fileHashDictionary = @{}

    # Load file|hash from baseline.txt and store them in a dictionary
    $filePathsAndHashes = Get-Content -Path C:\Users\santh\OneDrive\Desktop\PowerShell-Integrity-FIM-main\PowerShell-Integrity-FIM-main\baseline.txt
    
    foreach ($f in $filePathsAndHashes) {
        $split = $f.Split("|")
        $fileHashDictionary[$split[0]] = $split[1]
    }

    # Begin (continuously) monitoring files with saved Baseline
    while ($true) {
        Start-Sleep -Seconds 1
        
        $files = Get-ChildItem -Path C:\Users\santh\OneDrive\Desktop\PowerShell-Integrity-FIM-main\PowerShell-Integrity-FIM-main\Files

        # For each file, calculate the hash, and compare with baseline
        foreach ($f in $files) {
            $hash = Calculate-File-Hash $f.FullName

            # Notify if a new file has been created
            if (-not $fileHashDictionary.ContainsKey($f.FullName)) {
                Write-Host "$($f.FullName) has been created!" -ForegroundColor Green
            } else {
                # Notify if a file has been changed
                if ($fileHashDictionary[$f.FullName] -ne $hash.Hash) {
                    Write-Host "$($f.FullName) has changed!!!" -ForegroundColor Yellow
                }
            }
        }

        # Check if any baseline files have been deleted
        foreach ($key in $fileHashDictionary.Keys) {
            $baselineFileStillExists = Test-Path -Path $key
            if (-not $baselineFileStillExists) {
                Write-Host "$($key) has been deleted!" -ForegroundColor DarkRed -BackgroundColor Gray
            }
        }
    }
}
